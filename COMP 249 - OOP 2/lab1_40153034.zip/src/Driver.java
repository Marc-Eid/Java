
public class Driver {

	public static void main(String[] args) {
		
		Person josh = new Person("josh", 10, 'm');
		
		System.out.println(josh);
	}

}
